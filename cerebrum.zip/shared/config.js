module.exports = {
    PORT: 8080,
    URL: 'http://localhost:8080',
    MONGODB_URI: 'mongodb://localhost/cerebrum'
};